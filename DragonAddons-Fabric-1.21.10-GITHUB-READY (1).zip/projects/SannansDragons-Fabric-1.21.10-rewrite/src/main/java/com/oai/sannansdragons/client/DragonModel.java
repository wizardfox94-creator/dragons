package com.oai.sannansdragons.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

public final class DragonModel extends EntityModel<DragonRenderState> {
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart tail;
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public DragonModel(ModelPart root) {
        super(root);
        body = root.getChild("body");
        head = root.getChild("head");
        tail = root.getChild("tail");
        leftWing = root.getChild("left_wing");
        rightWing = root.getChild("right_wing");
        leftLeg = root.getChild("left_leg");
        rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body",
            CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -4.0F, -8.0F, 10.0F, 8.0F, 16.0F),
            PartPose.offset(0.0F, 15.0F, 0.0F));
        root.addOrReplaceChild("head",
            CubeListBuilder.create().texOffs(0, 25).addBox(-3.5F, -3.5F, -5.0F, 7.0F, 7.0F, 7.0F)
                .texOffs(28, 25).addBox(-2.5F, -1.5F, -8.0F, 5.0F, 3.0F, 4.0F),
            PartPose.offset(0.0F, 10.0F, -7.0F));
        root.addOrReplaceChild("tail",
            CubeListBuilder.create().texOffs(30, 0).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 13.0F),
            PartPose.offset(0.0F, 15.0F, 7.0F));
        root.addOrReplaceChild("left_wing",
            CubeListBuilder.create().texOffs(0, 42).addBox(0.0F, -0.5F, -4.0F, 11.0F, 1.0F, 9.0F),
            PartPose.offset(4.0F, 12.0F, -1.0F));
        root.addOrReplaceChild("right_wing",
            CubeListBuilder.create().texOffs(0, 42).mirror().addBox(-11.0F, -0.5F, -4.0F, 11.0F, 1.0F, 9.0F),
            PartPose.offset(-4.0F, 12.0F, -1.0F));
        root.addOrReplaceChild("left_leg",
            CubeListBuilder.create().texOffs(44, 28).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
            PartPose.offset(3.0F, 17.0F, 4.0F));
        root.addOrReplaceChild("right_leg",
            CubeListBuilder.create().texOffs(44, 28).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
            PartPose.offset(-3.0F, 17.0F, 4.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(DragonRenderState state) {
        super.setupAnim(state);
        head.xRot = state.xRot * Mth.DEG_TO_RAD;
        head.yRot = state.yRot * Mth.DEG_TO_RAD;
        float walk = state.walkAnimationSpeed;
        float phase = state.walkAnimationPos * 0.65F;
        leftLeg.xRot = Mth.cos(phase) * 0.65F * walk;
        rightLeg.xRot = Mth.cos(phase + Mth.PI) * 0.65F * walk;
        float flap = Mth.sin(state.ageInTicks * 0.58F) * 0.58F;
        leftWing.zRot = 0.10F + flap;
        rightWing.zRot = -0.10F - flap;
        tail.yRot = Mth.sin(state.ageInTicks * 0.10F) * 0.18F;
        body.y = 15.0F + Mth.sin(state.ageInTicks * 0.12F) * 0.35F;
    }
}

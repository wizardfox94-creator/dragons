package com.oai.poisondragons.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.resources.ResourceLocation;
import com.oai.poisondragons.DragonEntities;

public final class DragonAddonClient implements ClientModInitializer {
    public static final ModelLayerLocation DRAGON_LAYER = new ModelLayerLocation(
        ResourceLocation.fromNamespaceAndPath("poisondragons_fabric", "companion_dragon"), "main");

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(DRAGON_LAYER, DragonModel::createBodyLayer);
        EntityRenderers.register(DragonEntities.DRAGON, DragonEntityRenderer::new);
    }
}

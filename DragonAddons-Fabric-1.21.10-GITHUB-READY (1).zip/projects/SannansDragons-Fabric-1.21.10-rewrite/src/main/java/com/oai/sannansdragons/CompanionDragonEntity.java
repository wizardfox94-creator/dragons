package com.oai.sannansdragons;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

public class CompanionDragonEntity extends TamableAnimal {
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(
        CompanionDragonEntity.class, EntityDataSerializers.INT);

    public CompanionDragonEntity(EntityType<? extends TamableAnimal> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Animal.createAnimalAttributes()
            .add(Attributes.MAX_HEALTH, 42.0D)
            .add(Attributes.MOVEMENT_SPEED, 0.24D)
            .add(Attributes.FOLLOW_RANGE, 40.0D)
            .add(Attributes.KNOCKBACK_RESISTANCE, 0.35D);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this, 1.15D, 7.0F, 2.0F));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.85D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(VARIANT, 0);
    }

    public int getVariant() { return this.entityData.get(VARIANT); }

    public void setVariant(int variant) {
        int max = DragonContent.SPECIES.length - 1;
        this.entityData.set(VARIANT, Math.max(0, Math.min(max, variant)));
    }

    @Override
    public void tick() {
        super.tick();
        // Gentle flight assist: a bonded dragon glides back when its owner gets far away.
        if (!this.level().isClientSide()) {
            LivingEntity owner = this.isTame() && !this.isOrderedToSit() ? this.getOwner() : null;
            if (owner != null && this.distanceToSqr(owner) > (double) DragonConfig.recallDistance * DragonConfig.recallDistance) {
                this.setNoGravity(true);
                this.getNavigation().stop();
                Vec3 target = owner.position().add(0.0D, 2.2D, 0.0D);
                Vec3 direction = target.subtract(this.position());
                if (direction.lengthSqr() > 0.01D) {
                    this.setDeltaMovement(this.getDeltaMovement().scale(0.78D)
                        .add(direction.normalize().scale(0.045D)));
                }
            } else if (!this.isInWater()) {
                this.setNoGravity(false);
            }
        }
    }

    /**
     * Vanilla follow-owner logic teleports at 12 blocks, which made the glide-recall in tick() unreachable.
     * Raising the threshold lets the dragon fly back first and teleport only when the owner is really far.
     * NOTE: deliberately without @Override - if this vanilla hook has a different name/signature in
     * 1.21.10 the method is simply unused and the build still compiles (see BUILD_REPORT.md).
     */
    public boolean shouldTryTeleportToOwner() {
        LivingEntity owner = this.getOwner();
        double limit = DragonConfig.teleportDistance;
        return owner != null && this.distanceToSqr(owner) >= limit * limit;
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (this.isTame() && this.isOwnedBy(player) && player.isCrouching() && held.isEmpty()) {
            if (!this.level().isClientSide()) this.setOrderedToSit(!this.isOrderedToSit());
            return InteractionResult.SUCCESS;
        }
        if (!this.isTame() && held.is(Items.SWEET_BERRIES)) {
            if (!player.getAbilities().instabuild) held.shrink(1);
            if (!this.level().isClientSide()) {
                if (this.random.nextInt(3) == 0) {
                    this.tame(player);
                    this.setOrderedToSit(false);
                    this.getNavigation().stop();
                    this.level().broadcastEntityEvent(this, (byte) 7);
                } else {
                    this.level().broadcastEntityEvent(this, (byte) 6);
                }
            }
            return InteractionResult.SUCCESS;
        }
        if (this.isTame() && this.isOwnedBy(player) && held.is(Items.APPLE)) {
            if (!this.level().isClientSide()) {
                this.heal(5.0F);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false; // These dragons are companions; breeding is intentionally disabled.
    }

    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        CompanionDragonEntity child = new CompanionDragonEntity(DragonEntities.DRAGON, level);
        child.setVariant(this.getVariant());
        return child;
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("dragon_variant", this.getVariant());
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.setVariant(input.getInt("dragon_variant").orElse(0));
    }
}

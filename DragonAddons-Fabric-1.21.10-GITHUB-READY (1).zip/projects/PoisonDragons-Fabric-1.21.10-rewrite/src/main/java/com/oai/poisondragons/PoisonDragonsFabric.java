package com.oai.poisondragons;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.GenerationStep;

public final class PoisonDragonsFabric implements ModInitializer {
    public static final String MOD_ID = "poisondragons_fabric";

    @Override
    public void onInitialize() {
        DragonConfig.load();
        DragonEntities.registerAttributes();
        DragonContent.initialize();
        Registry.register(BuiltInRegistries.FEATURE,
            ResourceLocation.fromNamespaceAndPath(MOD_ID, "dragon_nest"), new DragonNestFeature());
        if (DragonConfig.nestEnabled) {
            BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(),
                GenerationStep.Decoration.VEGETAL_DECORATION, DragonWorldgen.NEST_PLACED);
        }
        DragonGuardianAura.register();
    }
}

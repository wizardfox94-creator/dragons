package com.oai.sannansdragons;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

public final class HatchingDragonEggBlock extends Block {
    public static final IntegerProperty HATCH_STAGE = IntegerProperty.create("hatch_stage", 0, 2);
    private final int variant;

    public HatchingDragonEggBlock(int variant, Properties properties) {
        super(properties);
        this.variant = variant;
        this.registerDefaultState(this.stateDefinition.any().setValue(HATCH_STAGE, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HATCH_STAGE);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!level.getBlockState(pos.above()).isAir()) return;
        if (random.nextInt(100) >= DragonConfig.hatchAdvanceChancePercent) return;
        int stage = state.getValue(HATCH_STAGE);
        if (stage < 2) {
            level.setBlock(pos, state.setValue(HATCH_STAGE, stage + 1), 3);
            return;
        }
        CompanionDragonEntity hatchling = new CompanionDragonEntity(DragonEntities.DRAGON, level);
        hatchling.setVariant(this.variant);
        hatchling.setBaby(true);
        hatchling.setPersistenceRequired();
        hatchling.snapTo(pos.getX() + 0.5D, pos.getY() + 0.15D, pos.getZ() + 0.5D,
            random.nextFloat() * 360.0F, 0.0F);
        level.addFreshEntity(hatchling);
        level.removeBlock(pos, false);
    }
}

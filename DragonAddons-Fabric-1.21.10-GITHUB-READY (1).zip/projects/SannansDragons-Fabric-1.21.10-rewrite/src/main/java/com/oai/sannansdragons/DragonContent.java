package com.oai.sannansdragons;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class DragonContent {
    public static final String[] SPECIES = new String[] { "aethergale", "bloom", "duskwraith", "earth", "emberghoul", "frostbane", "mossy", "riftwing", "sound", "starwyrm", "triplelash" };
    private static final List<Item> DECOR_ITEMS = new ArrayList<>();
    private static final List<Item> EGG_ITEMS = new ArrayList<>();
    public static final List<Block> EGGS = new ArrayList<>();
    public static Block NEST;

    private DragonContent() {}

    public static void initialize() {
registerSimpleBlock("skyreef_glowstone", 1.0F, 3.0F);
registerSimpleBlock("emberwood_log", 2.0F, 6.0F);
registerSimpleBlock("blackbranch_log", 2.0F, 6.0F);
registerSimpleBlock("echo_stone", 2.0F, 6.0F);
registerSimpleBlock("overgrown_dragonstone", 2.0F, 6.0F);
registerSimpleBlock("dragon_moss", 0.8F, 2.4F);
registerSimpleBlock("warm_crystal", 1.5F, 4.5F);
registerSimpleBlock("violet_crystal", 1.5F, 4.5F);
registerSimpleBlock("violet_moss", 0.8F, 2.4F);
registerSimpleBlock("aethergale_ore", 3.0F, 9.0F);
registerSimpleBlock("bloom_ore", 3.0F, 9.0F);
registerSimpleBlock("duskwraith_ore", 3.0F, 9.0F);
registerSimpleBlock("earth_ore", 3.0F, 9.0F);
registerSimpleBlock("emberghoul_ore", 3.0F, 9.0F);
registerSimpleBlock("mossy_ore", 3.0F, 9.0F);
registerSimpleBlock("riftwing_ore", 3.0F, 9.0F);
registerSimpleBlock("sound_ore", 3.0F, 9.0F);
registerSimpleBlock("starwyrm_ore", 3.0F, 9.0F);
registerEgg("aethergale_egg", 0);
registerEgg("bloom_egg", 1);
registerEgg("duskwraith_egg", 2);
registerEgg("earth_egg", 3);
registerEgg("emberghoul_egg", 4);
registerEgg("frostbane_egg", 5);
registerEgg("mossy_egg", 6);
registerEgg("riftwing_egg", 7);
registerEgg("sound_egg", 8);
registerEgg("starwyrm_egg", 9);
registerEgg("triplelash_egg", 10);
        NEST = registerSimpleBlock("dragon_nest", 1.0F, 2.0F);
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS)
            .register(entries -> DECOR_ITEMS.forEach(entries::accept));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS)
            .register(entries -> EGG_ITEMS.forEach(entries::accept));
    }

    private static Block registerSimpleBlock(String path, float hardness, float resistance) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("sannan_dragons_fabric", path);
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        Block block = new Block(BlockBehaviour.Properties.of().strength(hardness, resistance).setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        DECOR_ITEMS.add(item);
        return block;
    }

    private static Block registerEgg(String path, int variant) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("sannan_dragons_fabric", path);
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        HatchingDragonEggBlock block = new HatchingDragonEggBlock(variant,
            BlockBehaviour.Properties.of().strength(0.55F).noCollission().noOcclusion().randomTicks().setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        EGGS.add(block);
        EGG_ITEMS.add(item);
        return block;
    }
}

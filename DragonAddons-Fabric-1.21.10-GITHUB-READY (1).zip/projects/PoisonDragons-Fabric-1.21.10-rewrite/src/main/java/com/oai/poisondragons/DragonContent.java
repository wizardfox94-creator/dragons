package com.oai.poisondragons;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class DragonContent {
    public static final String[] SPECIES = new String[] { "sunstone", "obsidian", "jade", "amethyst" };
    private static final List<Item> DECOR_ITEMS = new ArrayList<>();
    private static final List<Item> EGG_ITEMS = new ArrayList<>();
    public static final List<Block> EGGS = new ArrayList<>();
    public static Block NEST;

    private DragonContent() {}

    public static void initialize() {
registerSimpleBlock("malachite_ore", 3.0F, 9.0F);
registerSimpleBlock("deepslate_malachite_ore", 4.0F, 12.0F);
registerSimpleBlock("raw_malachite_block", 3.0F, 9.0F);
registerSimpleBlock("malachite_block", 3.0F, 9.0F);
registerSimpleBlock("malachite_pile", 1.0F, 3.0F);
registerEgg("sunstone_egg", 0);
registerEgg("obsidian_egg", 1);
registerEgg("jade_egg", 2);
registerEgg("amethyst_egg", 3);
        NEST = registerSimpleBlock("dragon_nest", 1.0F, 2.0F);
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS)
            .register(entries -> DECOR_ITEMS.forEach(entries::accept));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS)
            .register(entries -> EGG_ITEMS.forEach(entries::accept));
    }

    private static Block registerSimpleBlock(String path, float hardness, float resistance) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("poisondragons_fabric", path);
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        Block block = new Block(BlockBehaviour.Properties.of().strength(hardness, resistance).setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        DECOR_ITEMS.add(item);
        return block;
    }

    private static Block registerEgg(String path, int variant) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("poisondragons_fabric", path);
        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        HatchingDragonEggBlock block = new HatchingDragonEggBlock(variant,
            BlockBehaviour.Properties.of().strength(0.55F).noCollission().noOcclusion().randomTicks().setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        BlockItem item = new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);
        EGGS.add(block);
        EGG_ITEMS.add(item);
        return block;
    }
}

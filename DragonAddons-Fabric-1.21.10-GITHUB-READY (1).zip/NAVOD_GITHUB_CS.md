# Jak z toho dostat JAR soubory (GitHub Actions, zdarma)

1. Na https://github.com vytvoř nový repozitář. Doporučuji **Private** (viz poznámka o licencích níže).
2. Rozbal tento ZIP a nahraj **celý obsah** do kořene repozitáře tak, aby `.github/workflows/build.yml` a složka `projects/` byly v kořeni:
   - webově: *Add file → Upload files* a přetáhni všechny složky (včetně `.github`), nebo
   - příkazy: `git init && git add -A && git commit -m "init" && git branch -M main && git remote add origin <URL> && git push -u origin main`
3. Otevři záložku **Actions**. Build se spustí sám (případně *Build Dragon Addons → Run workflow*).
4. Po dokončení otevři běh a dole v sekci **Artifacts** stáhni:
   - `poison-dragons-fabric-1.21.10` → JAR Poison Dragons
   - `sannans-dragons-fabric-1.21.10` → JAR Sannan's Dragons
5. **Pokud build spadne** (což je u kódu, který nikdo nekompiloval, pravděpodobné): stáhni artefakt `...-build-log` nebo zkopíruj červené řádky z logu a pošli mi je. Opravím zdrojáky a nahraješ novou verzi.

Do `mods/` pak patří: oba JARy, Fabric API 0.137.0+1.21.10, Ice and Fire 2.1.13-beta.14.3+1.21.10, Rampart 1.1.0+1.21.10.

## Poznámka k licencím
Do tohoto balíčku jsem záměrně **nedal** původní Forge JARy ani JAR Ice and Fire/Rampart (jsou pro build zbytečné). Původní módy mají licenci „All Rights Reserved“, takže je nezveřejňuj v repozitáři.

# BUILD_REPORT – Poison Dragons / Sannan's Dragons (Fabric 1.21.10)

## Souhrn
**JAR soubory NEBYLY sestaveny.** Prostředí, ve kterém jsem pracoval, nemá přístup k internetu
(`maven.fabricmc.net` se nepodařilo přeložit) a neobsahuje Gradle, Minecraft ani Fabric API. Gradle build, spuštění
klienta/serveru ani žádný herní test proto neproběhly. Dodávám revidované zdroje, skripty pro sestavení a tento report.
`build-output/` záměrně chybí – nechci dodávat JAR, který nikdo nesestavil.

## Co bylo skutečně provedeno
| Kontrola | Výsledek |
|---|---|
| Rozbalení handoff ZIPu, přečtení `CLAUDE_TASK.md` | provedeno |
| `fabric.mod.json` obou referenčních JARů (Ice and Fire, Rampart) | mod ID `iceandfire` 2.1.13-beta.14.3+1.21.10, `rampart` 1.1.0+1.21.10; oba MC 1.21.10, Java ≥21, Fabric Loader ≥0.18.2, Fabric API `*`; Ice and Fire vyžaduje `rampart >=1.1.0` |
| Validace všech JSON souborů (blockstates, modely, items, loot, worldgen, lang, tagy) | 0 chyb v obou projektech |
| Kontrola odkazů na modely a textury (`parent`, `model`, `textures`) | 0 chybějících odkazů |
| Každý blockstate má item definici i loot table | ano (obě mody) |
| Entity textury pro všechny varianty (4 + 11), velikost 64×64 | všechny přítomny |
| Syntaxe všech 26 Java souborů (parser `javac`, bez Minecraft knihoven) | bez syntaktických chyb (chyby typu „cannot find symbol“ jsou očekávané bez závislostí) |
| `DragonConfig` přeložena a spuštěna proti stubu `FabricLoader` | vytvoří výchozí soubor, ořezává hodnoty do rozsahů, neplatný vstup → výchozí hodnota |

## Co NEBYLO provedeno (a nesmí se tvrdit)
- `gradle build` (kompilace proti MC 1.21.10 + Fabric API 0.137.0+1.21.10): **neproběhla**.
- Načtení modů s Fabric Loaderem, Ice and Fire a Rampart: **neproběhlo**. Kompatibilita je ověřena jen staticky (ID, verze, deklarované závislosti).
- Registrace entit/bloků za běhu, render 4 + 11 variant, líhnutí 15 vajec, ochočení, uložení/načtení, generování hnízd: **netestováno**.

## Provedené změny ve zdrojích (všechny nezkompilované)
1. `DragonConfig` (`config/<modid>.properties`): rychlost líhnutí, zapnutí hnízd, aura, vzdálenosti přilétnutí/teleportu.
2. Vejce: líhnutí řízené `hatchAdvanceChancePercent`; přidáno `.noOcclusion()`, aby vejce nevytvářelo díry v sousedních blocích.
3. Logická chyba: vanilla follow-owner teleportuje na 12 blocích, přilétnutí začínalo až na 14 → bylo nedosažitelné. Přidán hook `shouldTryTeleportToOwner()` (bez `@Override`, aby build nespadl, pokud se v 1.21.10 jmenuje jinak – pak se oprava neuplatní).
4. Aura ochránce: poloměr a vypínač z configu (efekt dál dostává jen vlastník dané entity).
5. `fabric.mod.json`: odstraněn `rampart` (tranzitivní přes `iceandfire`, addon jej nepoužívá); `iceandfire` zůstává.
6. Přidány `data/minecraft/tags/block/mineable/{pickaxe,axe,hoe}.json`.

## Příkazy
```bash
# Java 21, Gradle 8.14+, internet
./build.sh            # Linux/macOS  (build.bat na Windows)
# nebo v každém projektu zvlášť:
cd PoisonDragons-Fabric-1.21.10-rewrite && gradle build
cd SannansDragons-Fabric-1.21.10-rewrite && gradle build
```
JAR vznikne v `build/libs/` (bez `-sources`). Při chybách kompilace pošli výpis – nejpravděpodobnější místa jsou níže.

## Známá rizika a omezení (z čtení kódu, neověřeno kompilátorem)
- **API drift 1.21.10**: ověřit `Entity#moveTo` v `HatchingDragonEggBlock` (v novějších verzích mohlo být přejmenováno), viditelnost `EntityRenderers.register` (případně Fabric API alternativa), a že existuje `loom_version=1.13.6` pro Gradle ≥8.14.
- **Průhlednost vajec**: 12 (Poison) a 33 (Sannan) textur vajec má alfa kanál, ale blok není zaregistrován jako cutout vrstva. Pokud se v průhledných místech objeví černá, je potřeba registrovat blok přes `BlockRenderLayerMap` (přesný název/podpis ověřit v Fabric API 0.137.0).
- Vejce používá celý kvádr jako obrys; model je `cross`. Mládě se nezmenšuje (chybí baby-scale v modelu).
- Draci se nespawnují přirozeně; vznikají z vajec (hnízda ve světě).
- Létání je pouze automatické přilétnutí k vlastníkovi; **nelze se na draka posadit**.
- Draci jsou samostatní společníci. Nejsou podtřídami draků Ice and Fire a nepoužívají jeho API.

## Parita s původními Forge módy (inventář podle názvů assetů a jazykových souborů)
| Oblast | Původní Forge 1.20.1 | Rewrite | Stav |
|---|---|---|---|
| Poison Dragons – druhy | acid_yellow, plague_black, toxic_green, venom_purple | sunstone, obsidian, jade, amethyst | **změněno** (jiné druhy a bez jedu) |
| Poison – výbava, kovárna, zbroj, nástroje (malachit), jedovaté efekty | ano (~64 itemů, 76 tříd) | jen malachitové bloky a hnízdo | **vynecháno** |
| Sannan's – 11 požadovaných druhů + vejce | ano | 11 variant + 11 vajec | implementováno (zjednodušeně) |
| Sannan's – další druhy (bloodstorm, crimsonclaw, lung, magma_reaper, plumed, purpelized, ruby) | ano | ne | **vynecháno** |
| Sannan's – ostatní (≈463 itemů, 55 entit, 641 tříd, zvuky, animace, struktury, bestiář, mamut, upíři, hrim…) | ano | ne | **vynecháno** |
| Ochočení, sezení, následování, růst, aura, hnízda, config | – | ano (nekompilováno) | implementováno, netestováno |

Plná parita nebyla dosažena a nelze ji tvrdit. Původní JARy jsou „All Rights Reserved“; byly použity jen pro inventář názvů, žádný kód ani asset z nich nebyl převzat.

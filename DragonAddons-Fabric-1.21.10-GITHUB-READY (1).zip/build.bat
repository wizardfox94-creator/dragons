@echo off
REM Builds both mods independently. Needs Java 21, Gradle 8.14+ in PATH and internet.
cd /d "%~dp0"
if not exist build-output mkdir build-output
pushd projects\PoisonDragons-Fabric-1.21.10-rewrite
call gradle build --no-daemon || (popd & exit /b 1)
for %%f in (build\libs\*.jar) do echo %%f | findstr /v /c:"-sources" >nul && copy /y "%%f" "..\..\build-output\PoisonDragons-Fabric-1.21.10.jar"
popd
pushd projects\SannansDragons-Fabric-1.21.10-rewrite
call gradle build --no-daemon || (popd & exit /b 1)
for %%f in (build\libs\*.jar) do echo %%f | findstr /v /c:"-sources" >nul && copy /y "%%f" "..\..\build-output\SannansDragons-Fabric-1.21.10.jar"
popd
echo Done. JARs are in build-output\

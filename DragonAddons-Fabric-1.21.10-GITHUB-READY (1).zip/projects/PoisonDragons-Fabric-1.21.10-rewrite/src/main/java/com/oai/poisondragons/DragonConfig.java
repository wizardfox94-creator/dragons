package com.oai.poisondragons;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Minimal properties-file config. File: config/poisondragons_fabric.properties (created with defaults on first start).
 * Values are clamped to sane ranges; invalid values fall back to the default.
 */
public final class DragonConfig {
    /** Chance (1-100 %) that a random tick advances an egg to its next stage. Egg needs 3 advances to hatch. */
    public static int hatchAdvanceChancePercent = 100;
    /** If false, the natural nest feature is not added to biomes (existing nests stay). */
    public static boolean nestEnabled = true;
    /** If false, tamed dragons give no passive resistance. */
    public static boolean guardianEnabled = true;
    /** Radius in blocks around the owner in which an owned dragon grants the guardian effect. */
    public static int guardianRadius = 28;
    /** Owner distance (blocks) beyond which a tamed, standing dragon flies back to the owner. */
    public static int recallDistance = 14;
    /** Owner distance (blocks) beyond which the dragon teleports instead of flying. Must be above recallDistance. */
    public static int teleportDistance = 48;

    private DragonConfig() {}

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("poisondragons_fabric.properties");
        Properties props = new Properties();
        if (Files.exists(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                props.load(in);
            } catch (IOException ignored) {
                // keep defaults
            }
        }
        hatchAdvanceChancePercent = readInt(props, "hatchAdvanceChancePercent", hatchAdvanceChancePercent, 1, 100);
        nestEnabled = Boolean.parseBoolean(props.getProperty("nestEnabled", Boolean.toString(nestEnabled)).trim());
        guardianEnabled = Boolean.parseBoolean(props.getProperty("guardianEnabled", Boolean.toString(guardianEnabled)).trim());
        guardianRadius = readInt(props, "guardianRadius", guardianRadius, 4, 128);
        recallDistance = readInt(props, "recallDistance", recallDistance, 6, 64);
        teleportDistance = readInt(props, "teleportDistance", teleportDistance, recallDistance + 4, 256);

        Properties out = new Properties();
        out.setProperty("hatchAdvanceChancePercent", Integer.toString(hatchAdvanceChancePercent));
        out.setProperty("nestEnabled", Boolean.toString(nestEnabled));
        out.setProperty("guardianEnabled", Boolean.toString(guardianEnabled));
        out.setProperty("guardianRadius", Integer.toString(guardianRadius));
        out.setProperty("recallDistance", Integer.toString(recallDistance));
        out.setProperty("teleportDistance", Integer.toString(teleportDistance));
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream os = Files.newOutputStream(file)) {
                out.store(os, "poisondragons_fabric config. Nest rarity is set in data/poisondragons_fabric/worldgen/placed_feature/dragon_nest.json (rarity_filter chance).");
            }
        } catch (IOException ignored) {
            // config is optional; running with in-memory values
        }
    }

    private static int readInt(Properties props, String key, int def, int min, int max) {
        try {
            int v = Integer.parseInt(props.getProperty(key, Integer.toString(def)).trim());
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }
}

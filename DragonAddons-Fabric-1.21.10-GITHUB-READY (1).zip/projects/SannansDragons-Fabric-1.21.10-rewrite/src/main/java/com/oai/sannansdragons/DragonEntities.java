package com.oai.sannansdragons;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class DragonEntities {
    private DragonEntities() {}

    public static final EntityType<CompanionDragonEntity> DRAGON = register(
        "companion_dragon",
        EntityType.Builder.<CompanionDragonEntity>of(CompanionDragonEntity::new, MobCategory.CREATURE)
            .sized(1.45F, 1.15F)
            .clientTrackingRange(10)
            .updateInterval(2)
    );

    private static <T extends Entity> EntityType<T> register(String path, EntityType.Builder<T> builder) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath("sannan_dragons_fabric", path);
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, id);
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
    }

    public static void registerAttributes() {
        FabricDefaultAttributeRegistry.register(DRAGON, CompanionDragonEntity.createAttributes());
    }
}
